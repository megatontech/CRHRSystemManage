﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FineUIPro.Examples.form
{
    public partial class layout_panel2 : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}