﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

namespace FineUIPro.Examples.iframe
{
    public partial class parent_simplepostback2 : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            PageContext.RegisterStartupScript("parent.__doPostBack('','param_from_simplepostback2');");
        }
    }
}
